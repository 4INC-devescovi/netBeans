/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esLettura;


/**
 *
 * @author diego
 */
public interface LetturaMessaggio {

    @Override
    public String toString();

    public String getTesto();
    
    public String leggi();
    
}
